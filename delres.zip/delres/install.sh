#!bin/sh


echo "Installation started"
[ "$UID" -eq 0 ] || { echo "This script must be run as root."; exit 1;}
chmod +x rmr && chmod +x res
if [ $? -eq 0 ]
then
mv rmr /bin && mv res /bin
if [ $? -eq 0]
then
echo "Installation complete"
else
echo "Error moving files to bin"
fi
else
echo "Permissions denied"
fi
